bin/fusefs devices/$1 $2 $3 -f -s
