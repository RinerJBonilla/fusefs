rm -rf devices/*
rm -rf bin/*